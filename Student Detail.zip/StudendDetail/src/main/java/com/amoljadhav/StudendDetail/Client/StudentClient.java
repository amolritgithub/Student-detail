package com.amoljadhav.StudendDetail.Client;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amoljadhav.StudendDetail.Controller.StudentController;
import com.amoljadhav.StudendDetail.Dao.StudentDao;
import com.amoljadhav.StudendDetail.Student.Student;
@RestController
public class StudentClient {
	@RequestMapping("studentclient")
	
	public	static ArrayList<Student> fetchStudent() throws Exception  {
		ArrayList<Student>arrayList = StudentController.fetchStudent();
		
		for (Student student : arrayList) {
			System.out.println(student.getId());
			System.out.println(student.getName());
		}
		return arrayList;
	}
	

}
