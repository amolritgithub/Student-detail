package com.amoljadhav.StudendDetail.Service;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amoljadhav.StudendDetail.Dao.StudentDao;
import com.amoljadhav.StudendDetail.Student.Student;
@RestController
public class StudentService {
	@RequestMapping("studentservice")
public	static ArrayList<Student> fetchStudent() throws Exception {
		ArrayList<Student> alstu= StudentDao.fetchStudent();
		
		for (Student student : alstu) {
			System.out.println(student);
		}

		return alstu;
	}

}
