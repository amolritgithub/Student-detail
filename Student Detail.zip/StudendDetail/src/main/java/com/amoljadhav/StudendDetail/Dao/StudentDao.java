package com.amoljadhav.StudendDetail.Dao;

import java.sql.Connection;


import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amoljadhav.StudendDetail.Student.Student;
@RestController
public class StudentDao {
	static ArrayList<Student> arrayList = new ArrayList<Student>();
	@RequestMapping("studentdao")
public	static ArrayList<Student> fetchStudent() throws Exception {
		System.out.println(1);
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println(2);
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "root");
		System.out.println(3);
		Statement statement=connection.createStatement();
		System.out.println(5);
		
		
		String sql = "select * from student";
		System.out.println(4);
		ResultSet resultSet=statement.executeQuery(sql);
		//ArrayList<Student> arrayList = new ArrayList<Student>();
		while(resultSet.next()){
			String id = resultSet.getString(1);
			String name= resultSet.getString(2);
			
			Student student = new Student(id, name);
			arrayList.add(student);
			System.out.println("sid:--"+ id);
			System.out.println("sname:--"+name);
		}
		return arrayList;
	}
	@PostMapping("addstudentdetile")
	public void addStudentDetile(@RequestBody Student student) throws Exception{
		System.out.println(student);
		
		
	}
	@RequestMapping("updatedStudentinformation")
	public ArrayList<Student> upStudent(){
	
		
		return arrayList;
	}
	
	
	
}
