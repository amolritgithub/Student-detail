package com.amoljadhav.StudendDetail.Controller;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amoljadhav.StudendDetail.Service.StudentService;
import com.amoljadhav.StudendDetail.Student.Student;
@RestController
public class StudentController {
	@RequestMapping("studentcontroller")
	public static ArrayList<Student> fetchStudent() throws Exception{
		ArrayList<Student> alstu = StudentService.fetchStudent();
		return alstu; 
	}

}
