package com.amoljadhav.StudendDetail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudendDetailApplicationTests {

	@Test
	void contextLoads() {
	}

}
